sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("invaudittrail.controller.View1",{onInit(){}})});
//# sourceMappingURL=App.controller.js.map