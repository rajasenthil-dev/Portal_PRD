sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("shiphis.controller.View1", {
      onInit() {
      }
  });
});