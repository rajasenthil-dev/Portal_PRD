sap.ui.define([],()=>{"use strict";return{removeLeadingZeros:function(e){if(typeof e==="string"&&/^\d+$/.test(e)){return String(Number(e))}return e}}});
//# sourceMappingURL=formatter.js.map