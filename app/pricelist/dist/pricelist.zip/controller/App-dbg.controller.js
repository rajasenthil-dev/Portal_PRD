sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("pricelist.controller.View1", {
      onInit() {
      }
  });
});