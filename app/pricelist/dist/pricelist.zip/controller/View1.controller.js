sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("pricelist.controller.View1",{onInit(){}})});
//# sourceMappingURL=View1.controller.js.map