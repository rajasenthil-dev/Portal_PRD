sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("invstatus.controller.View1", {
      onInit() {
      }
  });
});