sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (Controller) => {
  "use strict";

  return Controller.extend("bckorders.controller.View1", {
      onInit() {
      }
  });
});