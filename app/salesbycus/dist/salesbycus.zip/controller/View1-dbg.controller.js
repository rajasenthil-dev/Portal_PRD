sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/Dialog",
    "sap/m/Button",
    "sap/m/Image",
    "sap/m/MessageBox"
], (Controller, Dialog, Button, Image, MessageBox) => {
    "use strict";
    return Controller.extend("salesbycus.controller.View1", {
        onInit: function () {
            var oModel = this.getOwnerComponent().getModel();
            const oSmartTable = this.getView().byId("table0");
            const oTable = oSmartTable.getTable();
            this.bAuthorizationErrorShown = false;
            oModel.attachRequestFailed(function (oEvent) {
                var oParams = oEvent.getParameters();
                if (oParams.response.statusCode === "403") {
                    oTable.setNoData("No data available due to authorization restrictions");
                    oTable.setBusy(false)    
                    if(!this.bAuthorizationErrorShown) {
                        this.bAuthorizationErrorShown = true;
                        MessageBox.error("You do not have the required permissions to access this report.", {
                            title: "Unauthorized Access",
                            id: "messageBoxId1",
                            details: "Permission is required to access this report. Please contact your administrator if you believe this is an error or require access.",
                            contentWidth: "100px",
                        });
                    
                    }
                }
            });
            oTable.attachEvent("rowsUpdated", this._calculateTotals.bind(this));
            var oModelLogo = this.getOwnerComponent().getModel("logo");
            // Bind to the MediaFile entity with a filter
            var oBinding = oModelLogo.bindList("/MediaFile");
            // Fetch data
            oBinding.requestContexts().then(function (aContexts) {
                if (aContexts.length > 0) {
                    var oData = aContexts[0].getObject();
                    console.log("Manufacturer:", oData.MFGName);
                    console.log("File URL:", oData.url);
                    var sAppPath = sap.ui.require.toUrl("salesbycus").split("/resources")[0];
                    if(sAppPath === ".") {
                        sAppPath = "";
                    }
                    console.log("✅ Dynamic Base Path:", sAppPath);

                    var sSrcUrl = sAppPath + oData.url;
                        // Example: Set the image source
                    this.getView().byId("logoImage").setSrc(sSrcUrl);
                } else {
                        console.log("No media found for this manufacturer.");
                }
            }.bind(this));
        },
        _calculateTotals: function () {
            const oSmartTable = this.getView().byId("table0");
            const oTable = oSmartTable.getTable();
            const oBinding = oTable.getBinding("rows");
        
            if (!oBinding) {
                console.warn("Table binding is missing.");
                return;
            }
        
            const aContexts = oBinding.getContexts(0, oBinding.getLength());
            if (!aContexts) {
                console.warn("Data is not available for calculation.");
                return;
            }
        
            // Initialize totals
            const totals = aContexts.reduce((acc, oContext) => {
                const oData = oContext.getObject();
                if (!oData) return acc;
        
                // Sales & Amount Calculation
                acc.salesTotal += parseFloat(oData.AMOUNT_NETWR || 0);
        
                // Invoices Calculation (Count only 'Invoice' types)
                if (oData.VTEXT_FKART === "Invoice") {
                    acc.invoiceCount++;
                }
        
                // Lines Calculation (Count every row)
                acc.lineCount++;
        
                // Units Calculation (Units per case * Quantity)
                const unitsPerCase = parseFloat(oData.UNITS_PER_CASE || 0);
                const quantity = parseFloat(oData.QUANTITY_FKIMG || 0);
                acc.unitsTotal += unitsPerCase * quantity;
        
                // Footer Quantity Calculation (Sum QUANTITY_FKIMG)
                acc.quantityTotal += quantity;
        
                return acc;
            }, {
                salesTotal: 0,
                invoiceCount: 0,
                lineCount: 0,
                unitsTotal: 0,
                quantityTotal: 0
            });
        
            // Update Tiles
            this._updateTile("_IDGenNumericContent1", this.formatLargeNumber(totals.salesTotal)); // Sales
            this._updateTile("_IDGenNumericContent2", this.formatNumberWithCommas(totals.invoiceCount)); // Invoices
            this._updateTile("_IDGenNumericContent3", this.formatNumberWithCommas(totals.lineCount)); // Lines
            this._updateTile("_IDGenNumericContent4", this.formatNumberWithCommas(totals.unitsTotal)); // Units
        
            // Update Footer
            this._updateTile("FooterText1", this.formatNumberWithCommas(totals.quantityTotal)); // Quantity
            this._updateTile("FooterText2", this.formatCurrency(totals.salesTotal, "USD")); // Amount (Same as Sales)
        },
        
        _updateTile: function (sTileId, value) {
            const oTile = this.byId(sTileId);
            if (oTile) {
                oTile.setText(value);
            } else {
                console.warn(`Tile with ID ${sTileId} not found.`);
            }
        },
        onSearch: function () {
            const oSmartFilterBar = this.getView().byId("smartFilterBar");
            const oSmartTable = this.getView().byId("table0");
            const oBinding = oSmartTable.getTable().getBinding("rows");
        
            if (!oBinding) {
                console.warn("Table binding is missing.");
                return;
            }
        
            // Get selected value from the filter
            let sCurrentStatus = this.getView().byId("currentFilterBox").getSelectedKey();
        
            // Build the filter condition
            let aFilters = [];
            if (sCurrentStatus) {
                aFilters.push(new sap.ui.model.Filter("CURRENT", sap.ui.model.FilterOperator.Contains, sCurrentStatus));
            }
        
            // Apply the filter
            oBinding.filter(aFilters);
        },
        _formatRowHighlight: function (oValue) {
			// Your logic for rowHighlight goes here
			if (oValue === "NO") { 
				return "Information";
            }
			return "Success";
		},
        formatDate:function(value) {
            if (!value) return "";
            return value.replace(/(\d{4})(\d{2})(\d{2})/, '$1-$2-$3');
        },
        _formatDate: function (date) {
            
            if (!date) return ""; // Return empty string if no date is provided
        
            let oDate;
        
            // Handle string date (e.g., 'yyyyMMdd')
            if (typeof date === "string") {
                if (date.length === 8) { // Ensure the format is correct
                    const formattedDateString = date.slice(0, 4) + '-' + date.slice(4, 6) + '-' + date.slice(6, 8);
                    oDate = new Date(formattedDateString + "T00:00:00Z"); // Force UTC for consistency
                } else {
                    return ""; // Invalid string format
                }
            }
            // Handle Date object
            else if (date instanceof Date) {
                oDate = new Date(date.getTime()); // Clone to avoid mutation
            } else {
                return ""; // Unsupported type
            }
        
            // Check if the date is valid
            if (isNaN(oDate.getTime())) {
                return ""; // Return empty string for invalid date
            }
        
            // Adjust for local timezone only if necessary
            // Remove the offset adjustment if using UTC consistently across your app
            oDate.setMinutes(oDate.getMinutes() + oDate.getTimezoneOffset());
        
            // Format the date into a more readable string
            const oDateFormat = sap.ui.core.format.DateFormat.getDateInstance({
                style: "medium" // Use 'medium' style or customize as needed
            });
        
            // Return the formatted date
            return oDateFormat.format(oDate);
        },
        formatLargeNumber: function(value) {
            if (!value || isNaN(value)) return "0";
        
            const absValue = Math.abs(value); // Handle negative numbers safely
        
            if (absValue >= 1_000_000_000) {
                return (value / 1_000_000_000).toFixed(2) + "B";
            } else if (absValue >= 1_000_000) {
                return (value / 1_000_000).toFixed(2) + "M";
            } else if (absValue >= 1_000) {
                return (value / 1_000).toFixed(2) + "K";
            } 
            return value.toFixed(2); // For values less than 1K
        },
        formatNumberWithCommas: function(value) {
            if (!value || isNaN(value)) return "0";
        
            return value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        },
        formatCurrency: function(value, currency = "USD") {
            return new Intl.NumberFormat('en-US', {
                style: 'currency',
                currency: currency,
                minimumFractionDigits: 2,
                maximumFractionDigits: 2
            }).format(value);
        },
        _formatCurrency: function (value) {
            if (value == null || value === undefined) {
            return "";
            }
        
            // Get the locale
            var sLocale = sap.ui.getCore().getConfiguration().getLocale().getLanguage();
            var sCurrencyCode;
        
            switch (sLocale) {
                case "en-US":
                    sCurrencyCode = "USD";
                    break;
                case "en-CA":
                    sCurrencyCode = "CAD";
                    break;
                case "fr-CA":
                    sCurrencyCode = "CAD";
                    break;
            // Add more cases as needed for other languages/regions
                default:
                    sCurrencyCode = "USD"; // Default currency code
                    break;
            }
        
            // Create a NumberFormat instance with currency type
            var oNumberFormat = sap.ui.core.format.NumberFormat.getCurrencyInstance({
            "currencyCode": false,
            "customCurrencies": {
                "MyDollar": {
                    "isoCode": sCurrencyCode,
                    "decimals": 2
                }
            },
            groupingEnabled: true,
            showMeasure: true
            });
            return oNumberFormat.format(value, "MyDollar");
        },
        onInvoiceClick: function (oEvent) {
            const sInvoiceNumber = oEvent.getSource().getText();

            // Mock API Call
            const sMockAPI = `/mock-api/invoices/${sInvoiceNumber}`;
            this._fetchInvoiceImage(sMockAPI)
                .then((sImageUrl) => this._showInvoiceDialog(sImageUrl))
                .catch((err) => sap.m.MessageToast.show("Failed to load invoice"));
        },
        _fetchInvoiceImage: function (sUrl) {
            // Simulate API response
            return new Promise((resolve, reject) => {
                setTimeout(() => {
                    resolve("https://via.placeholder.com/600x800.png?text=Invoice");
                }, 1000);
            });
        },
        _showInvoiceDialog: function (sImageUrl) {
            const oDialog = new Dialog({
                title: "Invoice",
                content: new Image({ src: sImageUrl, width: "100%" }),
                buttons: [
                    new Button({
                        text: "Download",
                        press: () => this._downloadImage(sImageUrl)
                    }),
                    new Button({
                        text: "Print",
                        press: () => this._printImage(sImageUrl)
                    }),
                    new Button({
                        text: "Close",
                        press: function () {
                            oDialog.close();
                        }
                    })
                ]
            });
            oDialog.open();
        },

        _downloadImage: function (sImageUrl) {
            const oLink = document.createElement("a");
            oLink.href = sImageUrl;
            oLink.download = "invoice.png";
            oLink.click();
        },

        _printImage: function (sImageUrl) {
            const printWindow = window.open("");
            printWindow.document.write(`<img src='${sImageUrl}' style='width:100%;'/>`);
            printWindow.print();
            printWindow.close();
        }
        
    });
});